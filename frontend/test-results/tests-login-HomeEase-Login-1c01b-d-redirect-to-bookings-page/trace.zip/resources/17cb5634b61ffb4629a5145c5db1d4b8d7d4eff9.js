(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_15n-8ct._.js","static/chunks/0ny-_next_dist_compiled_next-devtools_index_01pjush.js","static/chunks/0ny-_next_dist_compiled_react-dom_2096w7e._.js","static/chunks/0ny-_next_dist_compiled_react-server-dom-turbopack_0-i8_4-._.js","static/chunks/0ny-_next_dist_compiled_0aums1r._.js","static/chunks/0ny-_next_dist_client_1xj97-b._.js","static/chunks/0ny-_next_dist_1fxv9oy._.js","static/chunks/0ny-_@swc_helpers_cjs_0_fmjyq._.js"],
    source: "entry"
});
